# Execute the following commands in current directory  
- **python**  
- **from serve import db**  
- **db.create_all()**  
- **python server.py**  

# A static chef must be insert into DB before execution of orders  

# To execute another file, use  
- **python client.py**