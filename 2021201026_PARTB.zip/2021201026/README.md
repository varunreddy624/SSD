# Requirements
-  Python 3 and above to serve content locally
-  Use **python -m http.server 8080** to serve the content of the present directory
-  Some images are loaded dynamically through internet, so internet connection is necessary
-  Admin Mode is implemented for a single paragraph only but can be extended to other elements as well similarly
-  Outputs are tested in chrome browser