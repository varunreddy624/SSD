# SSD ASSIGNMENT 1  
- Solution1: assumed that there is atleast one directory in the present directory  
- Solution2:  
- Solution3:  
- Solution4: assumed that both integers and roman numerals are valid
- Solution5: assumed that the directory **temp_activity** doesn't exist initially
